from tkinter import *
window=Tk()
window.geometry('285x500')
window.title("Calculator")
window.resizable(False,False)

def btn_val(number):
    num=txt_Box.get()
    txt_Box.delete(0,END)
    txt_Box.insert(0,str(num)+str(number))

def add():
    firstNumber=txt_Box.get()
    global activity
    activity="add"
    global a
    a=float(firstNumber)
    txt_Box.delete(0,END)

def sub():
    firstNumber=txt_Box.get()
    global activity
    activity="sub"
    global a
    a=float(firstNumber)
    txt_Box.delete(0,END)

def mul():
    firstNumber=txt_Box.get()
    global activity
    activity="mul"
    global a
    a=float(firstNumber)
    txt_Box.delete(0,END)

def div():
    firstNumber=txt_Box.get()
    global activity
    activity="div"
    global a
    a=float(firstNumber)
    txt_Box.delete(0,END)

def clear():
    txt_Box.delete(0,END)

def equals():
    secondNumber=txt_Box.get()
    txt_Box.delete(0,END)
    if activity=="add":
        txt_Box.insert(0,a+int(secondNumber))
    elif activity=="sub":
        txt_Box.insert(0,a-int(secondNumber))
    elif activity=="mul":
        txt_Box.insert(0,a*int(secondNumber))  
    elif activity=="div":
        txt_Box.insert(0,a/int(secondNumber))    

txt_Box=Entry(window,width=400,bg="White",fg="Black",font=("Helvetica", 30))
txt_Box.place(x=0,y=0,height=60)

btn=Button(window,width=3,height=3,text="7",command=lambda:btn_val(7))
btn.place(x=5,y=65)

btn=Button(window,width=3,height=3,text="8",command=lambda:btn_val(8))
btn.place(x=75,y=65)

btn=Button(window,width=3,height=3,text="9",command=lambda:btn_val(9))
btn.place(x=145,y=65)

btn=Button(window,width=3,height=3,text="=",command=equals)
btn.place(x=215,y=65)

btn=Button(window,width=3,height=3,text="4",command=lambda:btn_val(4))
btn.place(x=5,y=135)

btn=Button(window,width=3,height=3,text="5",command=lambda:btn_val(5))
btn.place(x=75,y=135)

btn=Button(window,width=3,height=3,text="6",command=lambda:btn_val(6))
btn.place(x=145,y=135)

btn=Button(window,width=3,height=3,text="+",command=add)
btn.place(x=215,y=135)

btn=Button(window,width=3,height=3,text="3",command=lambda:btn_val(3))
btn.place(x=5,y=205)

btn=Button(window,width=3,height=3,text="2",command=lambda:btn_val(2))
btn.place(x=75,y=205)

btn=Button(window,width=3,height=3,text="1",command=lambda:btn_val(1))
btn.place(x=145,y=205)

btn=Button(window,width=3,height=3,text="-",command=sub)
btn.place(x=215,y=205)

btn=Button(window,width=3,height=3,text="0",command=lambda:btn_val(0))
btn.place(x=5,y=275)

btn=Button(window,width=3,height=3,text="/",command=div)
btn.place(x=75,y=275)

btn=Button(window,width=3,height=3,text="x",command=mul)
btn.place(x=145,y=275)

btn=Button(window,width=3,height=3,text="C",command=clear)
btn.place(x=215,y=275)


mainloop()